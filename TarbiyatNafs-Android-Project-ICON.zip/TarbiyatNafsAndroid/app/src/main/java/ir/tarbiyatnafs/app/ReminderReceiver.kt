package ir.tarbiyatnafs.app
import android.app.*
import android.content.*
import android.os.Build
class ReminderReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent?){val p=PendingIntent.getActivity(c,1,c.packageManager.getLaunchIntentForPackage(c.packageName),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);val b=if(Build.VERSION.SDK_INT>=26)Notification.Builder(c,"daily") else Notification.Builder(c);val n=b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("وقت محاسبه نفس").setContentText("عملکرد امروزت را ثبت کن؛ چند بار لغزیدی و چند بار مقاومت کردی؟").setContentIntent(p).setAutoCancel(true).build();c.getSystemService(NotificationManager::class.java).notify(44,n)}}