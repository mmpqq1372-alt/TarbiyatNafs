package ir.tarbiyatnafs.app
import android.app.*
import android.os.*
import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.webkit.*
import android.widget.Toast
class MainActivity:Activity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); val w=WebView(this); w.settings.javaScriptEnabled=true; w.settings.domStorageEnabled=true; w.addJavascriptInterface(Bridge(this),"AndroidBridge"); w.webViewClient=WebViewClient(); setContentView(w); w.loadUrl("file:///android_asset/index.html"); if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("daily","یادآوری تربیت نفس",NotificationManager.IMPORTANCE_DEFAULT)); if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),2); schedule(22,30) }
fun schedule(h:Int,m:Int){val i=Intent(this,ReminderReceiver::class.java);val p=PendingIntent.getBroadcast(this,44,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);val c=java.util.Calendar.getInstance().apply{set(java.util.Calendar.HOUR_OF_DAY,h);set(java.util.Calendar.MINUTE,m);set(java.util.Calendar.SECOND,0);if(timeInMillis<=System.currentTimeMillis())add(java.util.Calendar.DAY_OF_YEAR,1)};(getSystemService(ALARM_SERVICE) as AlarmManager).setRepeating(AlarmManager.RTC_WAKEUP,c.timeInMillis,AlarmManager.INTERVAL_DAY,p)}
inner class Bridge(val c:Context){@JavascriptInterface fun setReminder(h:Int,m:Int){runOnUiThread{schedule(h.coerceIn(0,23),m.coerceIn(0,59));Toast.makeText(c,"یادآور تنظیم شد",Toast.LENGTH_SHORT).show()}}}}