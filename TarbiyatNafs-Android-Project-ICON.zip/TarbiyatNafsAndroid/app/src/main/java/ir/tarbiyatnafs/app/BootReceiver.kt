package ir.tarbiyatnafs.app
import android.content.*
import android.app.*
import java.util.Calendar
class BootReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent?){val p=PendingIntent.getBroadcast(c,44,Intent(c,ReminderReceiver::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);val t=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,22);set(Calendar.MINUTE,30);set(Calendar.SECOND,0);if(timeInMillis<System.currentTimeMillis())add(Calendar.DAY_OF_YEAR,1)};(c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setRepeating(AlarmManager.RTC_WAKEUP,t.timeInMillis,AlarmManager.INTERVAL_DAY,p)}}